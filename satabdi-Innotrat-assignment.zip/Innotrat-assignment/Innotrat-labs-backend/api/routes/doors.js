const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

const Door = require('../models/door');

router.get('/', (req, res, next) => {
    Door.find({}, function (err, doc) {
        res.status(200).json(
            doc
        );
        console.log(doc)
    });
});

router.post('/', (req, res, next) => {
    console.log(req.body)
    const door = Door({
        _id: mongoose.Types.ObjectId(),
        name: req.body.name
    });
    door.save().then(result => {
        console.log(result)
    })
        .catch(err => {
            console.log(err)
        })
    res.status(200).json({
        message: 'door created successfully',
        createdDoor: door
    });
});

router.put('/:doorId', async (req, res, next) => {
    console.log(req.params.doorId);
    let update = { isClosed: req.query.isClosed };
    let response = await Door.findByIdAndUpdate(req.params.doorId, update)
    res.status(200).json({
        message: 'Updated door status!',
        response
    });
});

router.delete('/:doorId', async (req, res, next) => {
    console.log(req.params.doorId);
    const item = await Door.findByIdAndDelete(req.params.doorId);
    res.status(200).json({
        item
    });
});

module.exports = router;