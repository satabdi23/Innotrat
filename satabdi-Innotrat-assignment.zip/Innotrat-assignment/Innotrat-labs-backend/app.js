const express = require('express');
const app = express();
const morgan = require('morgan');
const cors = require('cors');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const mongodbURI = "mongodb+srv://missidash:" + "olFmojwvzaBFgHPm" + "@cluster0.xjuotwt.mongodb.net/?retryWrites=true&w=majority"
console.log(mongodbURI)
mongoose.connect(mongodbURI, {
})

app.use(morgan('dev'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors(
    { "origin": '*' }
));


app.use('/doors', require('./api/routes/doors'))


module.exports = app;