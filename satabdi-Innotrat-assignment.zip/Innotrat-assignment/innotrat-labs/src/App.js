import {BsFillDoorOpenFill} from 'react-icons/bs';
import {BsFillDoorClosedFill} from 'react-icons/bs';
import './App.css';
import React, { useState, useEffect } from 'react'
import { useRive, useStateMachineInput } from 'rive-react';

function App() {
  
  const [door, setDoor] = useState(false);
  const [door2, setDoor2] = useState({});
  useEffect(() => {
    getDoorStatus()

  },[])

 

    const STATE_MACHINE_NAME = 'State Machine 1';
    const INPUT_NAME = 'change';
  
    const { RiveComponent, rive } = useRive({
      src: 'door.riv',
      stateMachines: STATE_MACHINE_NAME,
      artboard: 'New Artboard',
      autoplay: true,
      
    });
  
    var levelInput = useStateMachineInput(rive, STATE_MACHINE_NAME, INPUT_NAME);
    console.log(levelInput,'1')
    if(Object.keys(door2).length==0 && levelInput){
      setDoor2(levelInput.value)
    }

    const stateChange=()=>{
      // if(   levelInput && levelInput.value !=null ){
      //   levelInput.value=door
      // }
      console.log(door2,'2')

      }

    return (
      
     
      
      <div className='App'style={{ height: '500px', width: '100%' }}>
        {/* <RiveComponent /> */}
        {door?<BsFillDoorClosedFill size={128}/>:<BsFillDoorOpenFill size={128}/>}
        {/* <button onClick={() => (levelInput.value = true)}>0</button>
        <button onClick={() => (levelInput.value = false)}>1</button> */}
      <p>
        Door is {door?'closed':'open'}
      </p>
      </div>
    );
  
    function getDoorStatus() {
      console.log('hi')
      try {
        fetch(`http://localhost:5000/doors/`, {
          'method': 'GET',
          'headers': {
            'Content-Type': 'application/json',
            
          },
        }).then(res => {
          console.log(res.status);
          if (res.status == 200) {
            res.json().then(
              (result) => {
                setDoor(result[0].isClosed)
                console.log(result)
            stateChange()
              })
          }
        }
    
        )
      }
      catch (err) {
        console.log(err)
      }
    }
    

  
}


export default App;
